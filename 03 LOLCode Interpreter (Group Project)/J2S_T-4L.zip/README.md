# LOLcode Interpreter
## Running the program
* Run gui.py
* Select "Open File" and import a .lol file. The code should appear in the upper left box.
* Select "Execute". After executing, the user may see the following:
  * All lexemes in the code and their corresponding classifications (middle table)
  * Symbol table showing all variables and their corresponding values (rightmost table)
  * Terminal showing the output of the program (bottom text box)
  
